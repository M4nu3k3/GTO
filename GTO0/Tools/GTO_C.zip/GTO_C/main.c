#include <stdio.h>
#include <stdint.h>

#define MAX_REPONSES 20
#define OFFSET_REPONSES 0x1a

char traiteur_gto(filename) {   // "QCM_100_de_100.gto"
    FILE *fichier = fopen(filename, "rb");
    if (!fichier) {
        perror("Erreur ouverture fichier");
        return 1;
    }

    // Aller à l’offset de début des réponses
    fseek(fichier, 0, SEEK_END);
    long taille = ftell(fichier);
    rewind(fichier);

    if (taille < OFFSET_REPONSES + 2 * MAX_REPONSES) {
        printf("Fichier trop court ! Taille : %ld octets\n", taille);
        fclose(fichier);
        return 1;
    }

    fseek(fichier, OFFSET_REPONSES, SEEK_SET);

    uint8_t couples[2 * MAX_REPONSES];
    fread(couples, sizeof(uint8_t), 2 * MAX_REPONSES, fichier);
    fclose(fichier);

    printf("Réponses extraites (hex):\n");
    for (int i = 0; i < 2 * MAX_REPONSES; i++) {
        printf("%02X ", couples[i]);
    }
    printf("\n");

    // Comparaison
    int note = 0;
    for (int i = 0; i < MAX_REPONSES; i++) {
        char corr = (char)couples[2 * i];       // Correction
        char etud = (char)couples[2 * i + 1];   // Étudiant
        printf("Q%-2d : corr = %c, etud = %c => %s\n", i + 1, corr, etud,
               (corr == etud) ? "V" : "X");

        if (corr == etud) note++;
    }

    printf("Note finale : %d / %d\n", note, MAX_REPONSES);
}

int main(void) {
    // Génération CSV
    FILE *csv = fopen("resultats.csv", "w");
    if (csv) {
        fprintf(csv, "Note\n%d\n", note);
        fclose(csv);
    } else {
        perror("Erreur création CSV");
    }

    return 0;
}
